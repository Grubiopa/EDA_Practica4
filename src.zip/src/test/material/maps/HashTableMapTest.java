package test.material.maps;

import static org.junit.Assert.*;

import org.junit.Test;

public class HashTableMapTest {

	@Test
	public void testOffset() {
		fail("Not yet implemented");
	}

	@Test
	public void testAbstractHashTableMap() {
		fail("Not yet implemented");
	}

	@Test
	public void testAbstractHashTableMapInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testAbstractHashTableMapIntInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsEmpty() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindEntry() {
		fail("Not yet implemented");
	}

	@Test
	public void testGet() {
		fail("Not yet implemented");
	}

	@Test
	public void testPut() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemove() {
		fail("Not yet implemented");
	}

	@Test
	public void testIterator() {
		fail("Not yet implemented");
	}

	@Test
	public void testKeys() {
		fail("Not yet implemented");
	}

	@Test
	public void testValues() {
		fail("Not yet implemented");
	}

	@Test
	public void testEntries() {
		fail("Not yet implemented");
	}

	@Test
	public void testCheckKey() {
		fail("Not yet implemented");
	}

	@Test
	public void testHashValue() {
		fail("Not yet implemented");
	}

	@Test
	public void testRehash() {
		fail("Not yet implemented");
	}

	@Test
	public void testRehashInt() {
		fail("Not yet implemented");
	}

}
